module.exports = products = [
  {
    name: 'beverage',
    address:'3HX1eqruGnrV1P7ChmVdaRVQp9iJNN3vaT',
    price: 285,
    gpioPin: 17
  },
  {
    name:'test',
    address: '1NoeMxPd7uPeFEgmiqx6PLRRwfzheTDqix',
    price: 10000,
    gpioPin: 4
  }
];
