// evil portal helper
#pragma once

#include "wifi_marauder_app_i.h"

bool wifi_marauder_ep_read_html_file(WifiMarauderApp* app, uint8_t** the_html, size_t* html_size);