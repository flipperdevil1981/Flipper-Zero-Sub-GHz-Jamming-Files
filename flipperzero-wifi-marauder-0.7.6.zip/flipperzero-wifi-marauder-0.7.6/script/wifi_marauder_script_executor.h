#pragma once

#include "wifi_marauder_script.h"

void wifi_marauder_script_execute_start(void* context);
void wifi_marauder_script_execute_stage(WifiMarauderScriptStage* stage, void* context);
